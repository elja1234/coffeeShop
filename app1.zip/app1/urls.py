from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),  # Home page ('index.html')
    path('about/', views.about, name='about'),  # 'about.html'
    path('menu/', views.menu, name='menu'),  # 'menu.html'
    path('blog/', views.blog, name='blog'),  # 'blog.html'
    path('contact/', views.contact, name='contact'),  # 'contact.html'
    path('order/', views.order, name='order'),  # 'contact.html'
    path('product/<id>', views.productDetail, name="Product"),
    path('category/<str:category_name>/', views.productCategory, name='product_category'),
]
