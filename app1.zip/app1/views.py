from django.shortcuts import render
from .models import Product,Category


# Create your views here.
def index(request):
    products = Product.objects.all()  # Fetch all products from the database
    return render(request, 'index.html', {'products': products})  # Pass products to the template

def about(request):
    return render(request, 'about.html')  # Render 'about.html'

def menu(request):
    products = Product.objects.all()  # Fetch all products from the database
    return render(request, 'menu.html', {'products': products})  # Pass products to the template

def blog(request):
    return render(request, 'blog.html')  # Render 'blog.html'

def contact(request):
    return render(request, 'contact.html')  # Render 'contact.html'

def order(request):
    cat = Category.objects.all()
    products = Product.objects.filter(category == cat__name)  # Fetch all products from the database
    return render(request, 'order.html', {'products': products, 'category': cat,})  # Pass products to the template

def productDetail(request, id):
    productInfo = Product.objects.get(pk=id)
    context = {"productInfo":productInfo}
    return render(request, 'product.html', context)  # Render 'contact.html'

# def product_list(request):
#categories = Category.objects.prefetch_related('product_set').all()  # Fetch all categories with their related products
    # return render(request, 'order.html', {'categories': categories})

def productCategory(request, category_name):
    category = Category.objects.get(name=category_name)
    products = Product.objects.filter(category=category)
    return render(request, 'order.html', {'category': category, 'products': products})